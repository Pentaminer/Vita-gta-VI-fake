Минимальное приложение для PS Vita: показывает одну картинку и больше ничего.
Выход — кнопка PS, затем закрыть приложение в LiveArea.

Получить .vpk:
 1) GitHub: залей папку в репозиторий -> вкладка Actions -> build-vpk -> Run workflow
    -> скачай артефакт "vpk" (внутри picture_viewer.vpk).
 2) Локально (Linux/WSL + Docker), из этой папки:
    docker run --rm -v "$PWD":/src -w /src vitasdk/vitasdk sh -c "mkdir -p build && cd build && cmake .. && make"
 3) Со своим VitaSDK:  mkdir build && cd build && cmake .. && make

Готовый build/picture_viewer.vpk ставится через VitaShell.

Другая картинка:  python tools/make_raw.py моя.jpg image.raw  (нужен Pillow), затем пересобрать.
