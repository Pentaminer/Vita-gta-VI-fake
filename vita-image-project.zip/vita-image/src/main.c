#include <vitasdk.h>
#include <stdio.h>
#include <string.h>

#define SCREEN_W 960
#define SCREEN_H 544
#define FB_BYTES (SCREEN_W * SCREEN_H * 4)
#define ALIGN_UP(x, a) (((x) + (a) - 1) & ~((a) - 1))

int main(void) {
	/* framebuffer in CDRAM, size must be a multiple of 256 KiB */
	SceUID mem = sceKernelAllocMemBlock("fb", SCE_KERNEL_MEMBLOCK_TYPE_USER_CDRAM_RW,
	                                    ALIGN_UP(FB_BYTES, 256 * 1024), NULL);
	void *fb = NULL;
	sceKernelGetMemBlockBase(mem, &fb);

	/* image.raw = 960x544, bytes R,G,B,A per pixel */
	FILE *f = fopen("app0:image.raw", "rb");
	if (f) {
		fread(fb, 1, FB_BYTES, f);
		fclose(f);
	}

	SceDisplayFrameBuf frame;
	memset(&frame, 0, sizeof(frame));
	frame.size        = sizeof(frame);
	frame.base        = fb;
	frame.pitch       = SCREEN_W;
	frame.pixelformat = SCE_DISPLAY_PIXELFORMAT_A8B8G8R8;
	frame.width       = SCREEN_W;
	frame.height      = SCREEN_H;
	sceDisplaySetFrameBuf(&frame, SCE_DISPLAY_SETBUF_NEXTFRAME);

	for (;;)
		sceKernelDelayThread(1000 * 1000);
}
