# python make_raw.py picture.jpg image.raw   (needs Pillow)
import sys
from PIL import Image, ImageOps

src, dst = sys.argv[1], sys.argv[2]
im = ImageOps.contain(Image.open(src).convert("RGB"), (960, 544), Image.Resampling.LANCZOS)
canvas = Image.new("RGB", (960, 544), (0, 0, 0))
canvas.paste(im, ((960 - im.width) // 2, (544 - im.height) // 2))
open(dst, "wb").write(canvas.convert("RGBA").tobytes())
